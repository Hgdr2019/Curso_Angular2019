import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '../@bootstrap/ng-bootstrap';

@Component({
  selector: 'app-todo-modal',
  templateUrl: './todo-modal.component.html',
  styleUrls: ['./todo-modal.component.css']
})


export class TodoModalComponent implements OnInit {

  constructor(public modal: NgbActiveModal) { }

  


  ngOnInit() {
  }

}
